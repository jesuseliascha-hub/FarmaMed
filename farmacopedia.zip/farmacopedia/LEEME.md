# Qué hacer con esta carpeta — guía paso a paso

Tienes 5 elementos:

```
farmacopedia/
├── index.html          ← la app
├── sw.js                ← hace que funcione offline y detecta actualizaciones
├── manifest.json         ← hace que se pueda "instalar"
├── icons/                ← íconos de la app
└── .github/workflows/deploy.yml   ← publica todo automáticamente
```

No necesitas tocar nada de código. Solo sigue estos pasos **una sola vez**. Después de esto, actualizar la app es literalmente arrastrar el archivo nuevo.

---

## Paso 1 — Crea una cuenta de GitHub (si no tienes)
Ve a **github.com** → "Sign up". Es gratis.

## Paso 2 — Crea un repositorio nuevo
1. Arriba a la derecha, clic en **+** → **New repository**.
2. Nombre: `farmacopedia` (o el que quieras).
3. Marca **Public**.
4. NO marques "Add a README" (ya tienes uno).
5. Clic en **Create repository**.

## Paso 3 — Sube los archivos
En la página del repositorio recién creado:
1. Clic en **"uploading an existing file"** (o el botón **Add file → Upload files**).
2. Arrastra **toda la carpeta `farmacopedia`** completa (los navegadores modernos como Chrome permiten arrastrar carpetas enteras, no solo archivos sueltos — arrastra la carpeta, no el .zip).
   - Si tu navegador no acepta arrastrar carpetas, arrastra los archivos uno por uno **manteniendo la misma estructura**: `index.html`, `sw.js`, `manifest.json`, la carpeta `icons/` completa, y la carpeta `.github/workflows/deploy.yml`.
   - ⚠️ Importante: la carpeta `.github` empieza con un punto — es fácil que el explorador de archivos la oculte. Actívala como "archivos ocultos visibles" en tu computador antes de arrastrar, o dime y te doy la alternativa por línea de comandos.
3. Abajo, en "Commit changes", escribe algo como "Primera versión" y clic en **Commit changes**.

## Paso 4 — Activa GitHub Pages
1. En el repositorio, ve a **Settings** (pestaña de arriba).
2. En el menú izquierdo, clic en **Pages**.
3. En "Build and deployment" → "Source", selecciona **GitHub Actions** (no "Deploy from a branch").
4. No necesitas hacer nada más — el archivo `deploy.yml` que ya subiste se encarga del resto.

## Paso 5 — Espera 1–2 minutos y consigue tu link
1. Ve a la pestaña **Actions** del repositorio. Verás un proceso corriendo ("Publicar Farmacopedia en GitHub Pages"). Espera a que se ponga en ✅ verde.
2. Vuelve a **Settings → Pages**. Arriba va a aparecer un mensaje: *"Your site is live at..."* con tu link, algo como:
   `https://tu-usuario.github.io/farmacopedia/`
3. Abre ese link en el celular — ya deberías ver la app funcionando, instalable, con favoritos, comparador, todo.

## Paso 6 — Conecta el APK a esa URL
En el programa que uses para generar el APK (Median, WebIntoApp, Capacitor, MIT App Inventor con WebView, etc.), en vez de subir el `index.html` directo, configura la app para que **cargue esa URL** (`https://tu-usuario.github.io/farmacopedia/`) como página principal del WebView.

Así, el APK que instalen tus usuarios nunca cambia — pero el contenido que ve siempre es el más nuevo, porque lo está pidiendo a esa dirección web cada vez que abren la app.

**Muy importante en la configuración del WebView de tu generador de APK** (esto es lo que probablemente causaba el problema de "se ve gigante y descuadrado"): activa las opciones equivalentes a:
- `setUseWideViewPort(true)`
- `setLoadWithOverviewMode(true)`
- Permitir JavaScript y almacenamiento local (`localStorage`/`DOM storage`)

Si tu generador de APK no tiene esas opciones visibles, busca algo como "respetar viewport móvil" o "responsive mode".

---

## Cómo publicar una actualización después (cada vez que quieras cambiar algo)
1. Edita `index.html` (o pídeme que lo edite yo y te doy el archivo nuevo).
2. Abre `sw.js` y cambia la línea `const CACHE_VERSION = 'v1';` a `'v2'`, `'v3'`, etc. (esto es lo que avisa a los teléfonos que hay algo nuevo).
3. En GitHub, ve al archivo (`index.html` o `sw.js`), clic en el lápiz ✏️ (editar), pega el contenido nuevo o sube el archivo reemplazado, y clic en **Commit changes**.
4. Eso dispara automáticamente el flujo de publicación (puedes verlo en la pestaña **Actions**).
5. En 1–2 minutos, todos los que abran la app con conexión verán un banner: **"Hay una actualización disponible"** con un botón para actualizar al toque.

---

## Si prefieres usar git en vez del navegador (más rápido a la larga)
```bash
git clone https://github.com/tu-usuario/farmacopedia.git
cd farmacopedia
# copia/reemplaza tus archivos aquí
git add .
git commit -m "Actualización"
git push
```
Eso también dispara la publicación automática.
